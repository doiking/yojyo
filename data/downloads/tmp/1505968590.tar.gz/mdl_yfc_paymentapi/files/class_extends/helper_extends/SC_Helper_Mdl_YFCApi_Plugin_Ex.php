<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'helper/SC_Helper_Mdl_YFCApi_Plugin.php');
// }}}
/**
 * 決済モジュール用 プラグインヘルパークラス
 */
class SC_Helper_Mdl_YFCApi_Plugin_Ex extends SC_Helper_Mdl_YFCApi_Plugin{
}

