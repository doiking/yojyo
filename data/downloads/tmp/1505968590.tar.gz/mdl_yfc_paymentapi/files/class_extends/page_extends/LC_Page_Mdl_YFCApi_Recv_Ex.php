<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'pages/LC_Page_Mdl_YFCApi_Recv.php');
// }}}
/**
 * 結果非同期受信ヘルパークラス
 */
class LC_Page_Mdl_YFCApi_Recv_Ex extends LC_Page_Mdl_YFCApi_Recv {
}