<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'pages/LC_Page_Mypage_ChangeCard.php');
// }}}
/**
 * カード情報編集
 */
class LC_Page_Mypage_ChangeCard_Ex extends LC_Page_Mypage_ChangeCard {
}

