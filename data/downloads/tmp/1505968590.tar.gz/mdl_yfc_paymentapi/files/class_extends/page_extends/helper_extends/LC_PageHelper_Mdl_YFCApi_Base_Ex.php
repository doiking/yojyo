<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_PAGE_HELPER_PATH . "LC_PageHelper_Mdl_YFCApi_Base.php");
// }}}
/**
 * 決済モジュール 決済画面ヘルパー：ベース
 */
class LC_PageHelper_Mdl_YFCApi_Base_Ex extends LC_PageHelper_Mdl_YFCApi_Base{
}
