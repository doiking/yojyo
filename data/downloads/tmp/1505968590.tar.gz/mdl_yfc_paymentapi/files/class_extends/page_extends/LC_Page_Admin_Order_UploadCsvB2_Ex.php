<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . "pages/LC_Page_Admin_Order_UploadCsvB2.php");
// }}}
/**
 * B2CSV登録のページ拡張クラス.
 */
class LC_Page_Admin_Order_UploadCsvB2_Ex extends LC_Page_Admin_Order_UploadCsvB2 {
}
