<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . "pages/LC_Page_Admin_Mdl_YFCApi_Config.php");
// }}}
/**
 * 決済モジュール モジュール設定画面クラス
 */
class LC_Page_Admin_Mdl_YFCApi_Config_Ex extends LC_Page_Admin_Mdl_YFCApi_Config {
}
