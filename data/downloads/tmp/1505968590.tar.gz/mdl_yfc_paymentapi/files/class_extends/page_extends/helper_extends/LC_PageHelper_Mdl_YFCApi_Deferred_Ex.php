<?php
/**
 * Copyright(c)2015, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_PAGE_HELPER_PATH . "LC_PageHelper_Mdl_YFCApi_Deferred.php");
// }}}
/**
 * 決済モジュール 決済画面ヘルパー：後払い決済
 */
class LC_PageHelper_Mdl_YFCApi_Deferred_Ex extends LC_PageHelper_Mdl_YFCApi_Deferred
{
}
