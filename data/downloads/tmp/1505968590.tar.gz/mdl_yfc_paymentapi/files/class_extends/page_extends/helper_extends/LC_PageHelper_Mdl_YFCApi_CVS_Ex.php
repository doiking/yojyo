<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_PAGE_HELPER_PATH . "LC_PageHelper_Mdl_YFCApi_CVS.php");
// }}}
/**
 * 決済モジュール 決済画面ヘルパー：コンビニ
 */
class LC_PageHelper_Mdl_YFCApi_CVS_Ex extends LC_PageHelper_Mdl_YFCApi_CVS{
}
