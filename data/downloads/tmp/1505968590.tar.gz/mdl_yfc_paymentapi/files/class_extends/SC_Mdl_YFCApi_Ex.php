<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'SC_Mdl_YFCApi.php');
// }}}
/**
 * 決済モジュール基本クラス
 */
class SC_Mdl_YFCApi_Ex extends SC_Mdl_YFCApi {
}
