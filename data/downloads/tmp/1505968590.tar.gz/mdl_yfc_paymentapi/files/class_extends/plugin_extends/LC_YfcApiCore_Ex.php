<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'plugin/LC_YfcApiCore.php');
// }}}
/**
 * プラグイン 決済コアの拡張処理クラス
 */
class LC_YfcApiCore_Ex extends LC_YfcApiCore{
}
