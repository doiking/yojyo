<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MODULE_REALDIR . 'mdl_yfc_paymentapi/inc/include.php');
require_once(MDL_YFCAPI_CLASS_PATH . 'util/SC_Util_Mdl_YFCApi.php');
// }}}
/**
 * 決済モジュール用 汎用関数クラス
 */
class SC_Util_Mdl_YFCApi_Ex extends SC_Util_Mdl_YFCApi{
}

