<?php
/**
 * Copyright(c)2015, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MDL_YFCAPI_CLASS_PATH . 'client/SC_Mdl_YFCApi_Client_Deferred_Util.php');
// }}}
/**
 * 決済モジュール 決済処理: 後払い
 */
class SC_Mdl_YFCApi_Client_Deferred_Util_Ex extends SC_Mdl_YFCApi_Client_Deferred_Util {
}
