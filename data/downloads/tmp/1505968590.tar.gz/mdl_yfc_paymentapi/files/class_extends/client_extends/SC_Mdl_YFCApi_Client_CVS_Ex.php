<?php
/**
 * Copyright(c)2014, Yamato Financial Co.,Ltd. All rights reserved.
 */
// {{{ requires
require_once(MDL_YFCAPI_CLASS_PATH . 'client/SC_Mdl_YFCApi_Client_CVS.php');
// }}}
/**
 * 決済モジュール 決済処理: コンビニ
 */
class SC_Mdl_YFCApi_Client_CVS_Ex extends SC_Mdl_YFCApi_Client_CVS {
}
