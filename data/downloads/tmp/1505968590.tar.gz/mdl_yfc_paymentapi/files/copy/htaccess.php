php_flag mbstring.encoding_translation 0
php_value output_handler null
php_value variables_order EGPS
php_flag session.auto_start 0
php_flag session.use_trans_sid 1

order deny,allow
deny from all
allow from 218.40.0.72